from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login as auth_login, logout, get_user_model
from .models import *
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.core.mail import send_mail
import os

# Create your views here.
@login_required(login_url='login')
def index(request):
    return render(request, 'index.html')

@csrf_exempt
def contact(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get("name")
            email = data.get("email")
            subject = data.get("subject")
            message = data.get("message")

            if not all([name, email, subject, message]):
                return JsonResponse({"error": "All fields are required."}, status=400)

            # Email content
            email_subject = f"New Contact Form Submission: {subject}"
            email_body = f"""
            Name: {name}
            Email: {email}
            Subject: {subject}
            Message: {message}
            """

            # Sending email
            send_mail(
                subject=email_subject,
                message=email_body,
                from_email=os.getenv("EMAIL_HOST_USER"),  # Use your email
                recipient_list=["venkatagirishkoduru@gmail.com"],  # Admin email
                fail_silently=False,
            )

            return JsonResponse({"message": "Thank you for reaching out! We will get back to you soon."}, status=200)

        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid data format."}, status=400)

    return render(request, 'contact.html')

def login(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('edit_profile')
        else:
            messages.error(request, "Invalid email or password")
            return redirect('login')
    
    return render(request, 'login.html')

def signup(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password != confirm_password:
            messages.error(request, "Passwords do not match")
            return redirect('signup')

        User = get_user_model()  # This references your custom user model

        if User.objects.filter(username=email).exists():
            messages.error(request, "Email is already registered")
            return redirect('signup')

        user = User.objects.create_user(
            username=email, 
            email=email, 
            password=password
        )
        user.save()

        messages.success(request, "Account created successfully. Please log in.")
        return redirect('login')

    return render(request, 'signup.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def profile_view(request):
    profile = request.user.profile

    # Calculate average rating
    reviews = Review.objects.filter(reviewed_user=request.user)
    total_reviews = reviews.count()
    average_rating = reviews.aggregate_avg_rating = sum([review.rating for review in reviews]) / total_reviews if total_reviews > 0 else 0

    return render(request, 'profile.html', {
        'profile': profile,
        'average_rating': average_rating,
        'reviews': reviews
    })

@login_required(login_url='login')
def edit_profile(request):
    # Ensure profile exists or create one if missing
    profile, created = Profile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        bio = request.POST.get('bio')
        skills = request.POST.get('skills')
        interests = request.POST.get('interests')
        profile_picture = request.FILES.get('profile_picture')

        profile.bio = bio
        profile.skills = skills
        profile.interests = interests

        if profile_picture:
            profile.profile_picture = profile_picture

        profile.save()
        messages.success(request, "Profile updated successfully")
        return redirect('profile')

    return render(request, 'edit_profile.html', {'profile': profile})

@login_required
def search_users(request):
    query = request.GET.get('search')
    matched_profiles = []

    if query:
        skills = query.lower().split(',')
        profiles = Profile.objects.exclude(user=request.user)  # Exclude self from search

        # Find profiles with matching skills
        for profile in profiles:
            user_skills = [skill.strip().lower() for skill in profile.skills.split(',')]
            for skill in skills:
                if skill.strip() in user_skills:
                    matched_profiles.append(profile)
                    break

    return render(request, 'search_users.html', {'matched_profiles': matched_profiles, 'query': query})

@login_required
def send_request(request, receiver_id):
    """Send a skill exchange request."""
    if request.method == "POST":
        message = request.POST.get('message')
        receiver = User.objects.get(id=receiver_id)

        # Check if the user is trying to send a request to themselves
        if receiver == request.user:
            messages.error(request, "You cannot send a skill exchange request to yourself!")
            return redirect('search_users')

        # Prevent duplicate requests if pending request exists
        if SkillExchangeRequest.objects.filter(sender=request.user, receiver=receiver, status='pending').exists():
            messages.warning(request, "Request already sent!")
        else:
            SkillExchangeRequest.objects.create(sender=request.user, receiver=receiver, message=message)
            messages.success(request, "Request sent successfully!")

        return redirect('search_users')

@login_required
def view_requests(request):
    """View incoming requests."""
    received_requests = SkillExchangeRequest.objects.filter(receiver=request.user, status='pending')
    sent_requests = SkillExchangeRequest.objects.filter(sender=request.user)
    return render(request, 'view_requests.html', {'received_requests': received_requests, 'sent_requests': sent_requests})

@login_required
def respond_request(request, request_id, action):
    skill_request = SkillExchangeRequest.objects.get(id=request_id, receiver=request.user)

    if action == "accept":
        skill_request.status = "accepted"
        messages.success(request, "Request accepted!")
    elif action == "reject":
        skill_request.status = "rejected"
        messages.error(request, "Request rejected!")
    elif action == "complete":
        skill_request.status = "completed"
        skill_request.completed_at = timezone.now()
        messages.success(request, "Skill exchange marked as completed. You can now leave a review!")
    skill_request.save()
    return redirect('view_requests')


@login_required
def message_interface(request):
    """Display the message interface and mark messages as read."""
    # Mark all unread messages as read
    Message.objects.filter(receiver=request.user, is_read=False).update(is_read=True)

    # Fetch messages and users
    users = Profile.objects.exclude(user=request.user)
    messages = Message.objects.filter(receiver=request.user) | Message.objects.filter(sender=request.user)
    messages = messages.order_by('timestamp')

    return render(request, 'message_interface.html', {'users': users, 'messages': messages})

@csrf_exempt
@login_required
def send_message(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            receiver_id = data.get('receiver_id')
            content = data.get('content')

            if not receiver_id or not content:
                return JsonResponse({'status': 'error', 'message': 'Missing fields'}, status=400)

            receiver = User.objects.get(id=receiver_id)

            # Allow replying to received messages
            Message.objects.create(
                sender=request.user,
                receiver=receiver,
                content=content,
                is_read=False
            )
            return JsonResponse({'status': 'success', 'content': content}, status=201)

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

@login_required
def get_notifications(request):
    """Retrieve unread notifications."""
    notifications = Notification.objects.filter(user=request.user, is_read=False)
    data = [{'message': n.message, 'created_at': n.created_at.strftime('%Y-%m-%d %H:%M:%S')} for n in notifications]
    
    # Mark notifications as read
    notifications.update(is_read=True)
    
    return JsonResponse({'notifications': data})

@login_required
def unread_message_count(request):
    total_unread = Message.objects.filter(receiver=request.user, is_read=False).count()
    unread_counts = {}

    for message in Message.objects.filter(receiver=request.user, is_read=False):
        sender = message.sender.username
        unread_counts[sender] = unread_counts.get(sender, 0) + 1

    return JsonResponse({'total_unread': total_unread, 'per_user_counts': unread_counts})

@csrf_exempt
@login_required
def mark_messages_as_read(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            sender_username = data.get('sender_username')

            # Mark messages from the specified user as read
            Message.objects.filter(sender__username=sender_username, receiver=request.user, is_read=False).update(is_read=True)
            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

@login_required
def submit_review(request, request_id):
    skill_request = get_object_or_404(SkillExchangeRequest, id=request_id)

    if request.method == "POST":
        rating = int(request.POST.get('rating'))
        comment = request.POST.get('comment')

        reviewed_user = skill_request.receiver if skill_request.sender == request.user else skill_request.sender

        # Prevent duplicate reviews
        if Review.objects.filter(request=skill_request, reviewer=request.user).exists():
            messages.warning(request, "You've already reviewed this experience.")
            return redirect('view_reviews')

        # Save the review
        Review.objects.create(
            request=skill_request,
            reviewer=request.user,
            reviewed_user=reviewed_user,
            rating=rating,
            comment=comment
        )
        messages.success(request, "Review submitted successfully!")
        return redirect('view_reviews')

    # Pass the request ID to the template
    return render(request, 'submit_review.html', {'request_id': request_id})


@login_required
def leave_review(request, user_id):
    """Handle review submission."""
    if request.method == "POST":
        rating = int(request.POST.get('rating'))
        comment = request.POST.get('comment')
        reviewed_user = User.objects.get(id=user_id)

        # Validate rating
        if rating < 1 or rating > 5:
            messages.error(request, "Rating must be between 1 and 5.")
            return redirect('view_requests')

        # Create and save review
        Review.objects.create(
            reviewer=request.user,
            reviewed_user=reviewed_user,
            rating=rating,
            comment=comment
        )
        messages.success(request, "🎉 Review submitted successfully!")
        return redirect('view_requests')

    return redirect('view_requests')


@login_required
def view_reviews(request):
    reviews_received = Review.objects.filter(reviewed_user=request.user).order_by('-created_at')
    reviews_given = Review.objects.filter(reviewer=request.user).order_by('-created_at')

    return render(request, 'view_reviews.html', {'reviews_received': reviews_received, 'reviews_given': reviews_given})