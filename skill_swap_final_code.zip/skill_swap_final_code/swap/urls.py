from django.urls import path
from . import views
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('admin/', admin.site.urls),
    path('login/', views.login, name='login'),
    path('contact/', views.contact, name='contact'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/',  views.profile_view, name='profile'),
    path('profile/edit/',  views.edit_profile, name='edit_profile'),
    path('search/', views.search_users, name='search_users'),
    path('send_request/<int:receiver_id>/', views.send_request, name='send_request'),
    path('view_requests/', views.view_requests, name='view_requests'),
    path('respond_request/<int:request_id>/<str:action>/', views.respond_request, name='respond_request'),
    path('messages/', views.message_interface, name='message_interface'),
    path('send_message/', views.send_message, name='send_message'),
    path('unread_message_count/', views.unread_message_count, name='unread_message_count'),
    path('mark_messages_as_read/', views.mark_messages_as_read, name='mark_messages_as_read'),
    path('submit_review/<int:request_id>/', views.submit_review, name='submit_review'),
    path('view_reviews/', views.view_reviews, name='view_reviews'),
    path('leave_review/<int:user_id>/', views.leave_review, name='leave_review'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)